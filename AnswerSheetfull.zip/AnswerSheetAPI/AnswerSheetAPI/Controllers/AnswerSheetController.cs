﻿
using AnswerSheetAPI.App_Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
//using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace AnswerSheetAPI.Controllers
    {
        [ApiController]
        [Route("api/[controller]")]
        public class AnswerSheetController : ControllerBase
        {
            private readonly DataLayer _dataLayer;
            private readonly IHostEnvironment _env;
        private readonly IConfiguration _configuration;

        public AnswerSheetController(DataLayer dataLayer, IHostEnvironment env, IConfiguration configuration)
        {
            _dataLayer = dataLayer ?? throw new ArgumentNullException(nameof(dataLayer));
            _env = env ?? throw new ArgumentNullException(nameof(env));
            _configuration = configuration;
        }


        //public string GenerateToken(User user)
        //{
        //    var claims = new List<Claim>
        //{
        //    new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()), // User ID
        //    new Claim(ClaimTypes.Name, user.Username), // Username
        //    new Claim(ClaimTypes.Role, user.Role) // User Role
        //    // Add other claims as needed, e.g., FullName
        //    // new Claim("FullName", user.FullName)
        //};

        //    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
        //    var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        //    var token = new JwtSecurityToken(
        //        issuer: _configuration["Jwt:Issuer"],
        //        audience: _configuration["Jwt:Audience"],
        //        claims: claims,
        //        expires: DateTime.Now.AddDays(7), // Token valid for 7 days
        //        signingCredentials: credentials);

        //    return new JwtSecurityTokenHandler().WriteToken(token);
        //}


        [HttpPost("Login")]
        public async Task<IActionResult> Login([FromBody] JsonElement json)
        {
            try
            {
                // --- Extract username ---
                if (!json.TryGetProperty("username", out JsonElement usernameElement) ||
                    (usernameElement.ValueKind != JsonValueKind.String && usernameElement.ValueKind != JsonValueKind.Number))
                {
                    return BadRequest("Missing or invalid 'username' field.");
                }

                int UniqueId;
                if (usernameElement.ValueKind == JsonValueKind.Number)
                {
                    UniqueId = usernameElement.GetInt32();
                }
                else if (!int.TryParse(usernameElement.GetString(), out UniqueId))
                {
                    return BadRequest("Username must be an integer.");
                }

                // --- Extract password ---
                if (!json.TryGetProperty("password", out JsonElement passwordElement) ||
                    passwordElement.ValueKind != JsonValueKind.String)
                {
                    return BadRequest("Missing or invalid 'password' field.");
                }
                string password = passwordElement.GetString();

                // --- Check null/empty ---
                if (string.IsNullOrWhiteSpace(password))
                {
                    return BadRequest("Username and password cannot be empty.");
                }

                // --- Optional imageData ---
                string imageData = null;
                if (json.TryGetProperty("imageData", out JsonElement imageDataElement) &&
                    imageDataElement.ValueKind == JsonValueKind.String)
                {
                    imageData = imageDataElement.GetString();
                }

                // --- Validate user login ---
                var user = await _dataLayer.LoginUserAsync(UniqueId, password);
                if (user == null || user.Tables.Count == 0 || user.Tables[0].Rows.Count == 0 ||
                    user.Tables[0].Rows[0]["status"].ToString() != "success")
                {
                    return Unauthorized("Invalid credentials.");
                }

                string imagePath = null;

                if (!string.IsNullOrEmpty(imageData))
                {
                    string privateImagesFolder = Path.Combine(_env.ContentRootPath, "PrivateUserImages");
                    if (!Directory.Exists(privateImagesFolder))
                    {
                        Directory.CreateDirectory(privateImagesFolder);
                    }

                    string base64Only = imageData;
                    if (imageData.Contains(','))
                    {
                        base64Only = imageData.Split(',')[^1]; 
                    }

                    try
                    {
                        byte[] imageBytes = Convert.FromBase64String(base64Only);

                        string sanitizedUsername = UniqueId.ToString(); // or keep a username string if available
                        TimeZoneInfo istZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                        DateTime istTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, istZone);

                        string datePart = istTime.ToString("dd_MMMM_yyyy");     // 22_July_2025
                        string timePart = istTime.ToString("hh_mm_ss_tt");      // 10_57_55_PM
                        string uniqueId = Guid.NewGuid().ToString("N");

                        string fileName = $"{sanitizedUsername}-{datePart}-({timePart})-{uniqueId}.jpeg";


                        imagePath = Path.Combine(privateImagesFolder, fileName);
                        await System.IO.File.WriteAllBytesAsync(imagePath, imageBytes);

                        Console.WriteLine($"Image saved to: {imagePath}");

                        // --- Log user image upload ---
                        string status = user.Tables[0].Rows[0]["status"].ToString() ?? "success";
                        string ip = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown";
                        //string ip = HttpContext.Request.Headers["X-Forwarded-For"].FirstOrDefault();
                        await _dataLayer.MasterUserLog(UniqueId, status, fileName, ip);
                    }
                    catch (FormatException)
                    {
                        Console.Error.WriteLine($"Invalid base64 image data for user {UniqueId}.");
                    }
                    catch (Exception ex)
                    {
                        Console.Error.WriteLine($"Error saving image for user {UniqueId}: {ex.Message}");
                    }
                }
                else
                {
                    Console.WriteLine($"Login attempt for {UniqueId} without image data provided.");
                }
                string JsonData = JsonConvert.SerializeObject(user.Tables[0], Formatting.Indented);

                return Ok(new
                {
                    message = "Login successful",
                    data = JsonData
                });
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"Invalid JSON format received: {ex.Message}");
                return BadRequest("Invalid JSON format in request body.");
            }

        }




        // GET: api/AnswerSheet/Evaluation?subject={subject}&rollNumber={rollNumber}
        [HttpGet("Evaluation")]
            public async Task<IActionResult> GetEvaluation([FromQuery] string rollNumber)
            {
                try
                {
                    if (string.IsNullOrEmpty(rollNumber))
                    {
                        return BadRequest("Subject and rollNumber are required.");
                    }

                    var evaluation = await _dataLayer.GetEvaluation( rollNumber);
                    if (evaluation == null)
                    {
                        return NotFound($"No evaluation found for subject  roll number {rollNumber}.");
                    }

                    return Ok(evaluation);
                }
                catch (Exception ex)
                {
                    return StatusCode(500, $"Internal server error: {ex.Message}");
                }
            }

            // GET: api/AnswerSheet/EvaluationData?subject={subject}&rollNumber={rollNumber}
            [HttpGet("EvaluationData")]
            public async Task<IActionResult> GetEvaluationData( [FromQuery] string uniqueId)
            {
                try
                {
                    if (string.IsNullOrEmpty(uniqueId))
                    {
                        return BadRequest("UniqueID is required.");
                    }

                    var evaluationData = await _dataLayer.GetEvaluationData(uniqueId);
                    if (evaluationData == null)
                    {
                        return NotFound($"No evaluation data found for roll number {uniqueId}.");
                    }
                string jsondata = JsonConvert.SerializeObject(evaluationData.Tables,Formatting.Indented);
                    return Ok(jsondata);
                }
                catch (Exception ex)
                {
                    return StatusCode(500, $"Internal server error: {ex.Message}");
                }
            }

            // POST: api/AnswerSheet/SubmitEvaluation
            [HttpPost("SubmitEvaluation")]
            public IActionResult SubmitEvaluation([FromBody] JsonElement submission)
            {
                try
                {
                    // Validate required fields
                    if (!submission.TryGetProperty("subject", out JsonElement subjectElement) ||
                        !submission.TryGetProperty("rollNumber", out JsonElement rollNumberElement) ||
                        subjectElement.GetString() == null || rollNumberElement.GetString() == null)
                    {
                        return BadRequest("Invalid submission data. Subject and rollNumber are required.");
                    }

                    if (!submission.TryGetProperty("evaluationData", out JsonElement evaluationDataElement) ||
                        evaluationDataElement.ValueKind != JsonValueKind.Array || evaluationDataElement.GetArrayLength() == 0)
                    {
                        return BadRequest("Evaluation data is required and must be a non-empty array.");
                    }

                    // Extract fields
                    string? subject = subjectElement.GetString();
                    string? rollNumber = rollNumberElement.GetString();
                    string blankPages = submission.TryGetProperty("blankPages", out JsonElement blankPagesElement) &&
                                        blankPagesElement.ValueKind == JsonValueKind.Array
                        ? System.Text.Json.JsonSerializer.Serialize(blankPagesElement)
                        : "[]"; // Default to empty array if not provided
                    string evaluationData = System.Text.Json.JsonSerializer.Serialize(evaluationDataElement);

                    // Call DataLayer with raw JSON data
                    var evaluationId =  _dataLayer.SubmitEvaluation(subject, rollNumber, blankPages, evaluationData);

                    return Ok(new
                    {
                        Success = true,
                        Message = "Evaluation submitted successfully",
                        EvaluationId = evaluationId
                    });
                }
                catch (Exception ex)
                {
                    return BadRequest($"Invalid JSON format: {ex.Message}");
                }
           
            }

        // Update the constructor to accept IHostEnvironment and assign it



           
        }
    }