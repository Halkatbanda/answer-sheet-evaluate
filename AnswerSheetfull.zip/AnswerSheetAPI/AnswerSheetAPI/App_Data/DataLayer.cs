﻿using Microsoft.Data.SqlClient;
using System;
using System.Data;
using System.Text.Json;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace AnswerSheetAPI.App_Data
{
    public class DataLayer
    {
        private readonly string ConnectionString;

        public DataLayer(IConfiguration configuration)
        {
            ConnectionString = configuration.GetConnectionString("DBCon")
                ?? throw new ArgumentNullException(nameof(configuration), "DB connection string not found");
        }

        // GET: api/AnswerSheet

        public async Task<DataSet?> LoginUserAsync(int uniqueid, string password)
        {
            var ds = new DataSet();
            using (var conn = new SqlConnection(ConnectionString))
            {
                await conn.OpenAsync();
                using (var cmd = new SqlCommand("Evaluator_LoginUser", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@UniqueID", uniqueid);
                    cmd.Parameters.AddWithValue("@Password", password);
                    try
                    {
                        using (var adp = new SqlDataAdapter(cmd))
                        {
                            adp.Fill(ds);
                        }
                    }
                    catch
                    {
                        ds = null;
                    }
                }
            }

            return ds;
        }



        public async Task<object> getdata()
        {
            try
            {
                using var connection = new SqlConnection(ConnectionString); // IDE0063: already simplified
                await connection.OpenAsync();

                using var command = new SqlCommand(@"
                    SELECT TOP 10 
                        a.AnswerSheetId, 
                        st.RollNumber, 
                        s.SubjectCode, 
                        a.AnswerSheetUrl, 
                        a.TotalQuestions
                    FROM AnswerSheets a
                    INNER JOIN Students st ON a.StudentId = st.StudentId
                    INNER JOIN Subjects s ON a.SubjectId = s.SubjectId", connection); // IDE0063: already simplified

                using var reader = await command.ExecuteReaderAsync(); // IDE0063: already simplified
                var results = new List<Dictionary<string, object>>(); // IDE0090: 'new' expression can be simplified

                while (await reader.ReadAsync())
                {
                    var row = new Dictionary<string, object> // IDE0090: 'new' expression can be simplified
                    {
                        { "AnswerSheetId", reader.GetInt32(0) },
                        { "RollNumber", reader.GetString(1) },
                        { "SubjectCode", reader.GetString(2) },
                        { "AnswerSheetUrl", reader.GetString(3) },
                        { "TotalQuestions", reader.GetInt32(4) }
                    };
                    results.Add(row);
                }

                return results;
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to fetch answer sheets: " + ex.Message, ex);
            }
        }

        // GET: api/AnswerSheet/Evaluation
        public async Task<object> GetEvaluation( string rollNumber)
        {
            try
            {
                using var connection = new SqlConnection(ConnectionString); // IDE0063: already simplified
                await connection.OpenAsync();

                using var command = new SqlCommand(@"
                    SELECT 
                        e.EvaluationGuid,
                        e.BlankPages,
                        ed.QuestionNumber,
                        ed.Marks,
                        ed.CoordinateX,
                        ed.CoordinateY,
                        ed.PageNumber,
                        ed.Timestamp
                    FROM Evaluations e
                    INNER JOIN EvaluationDetails ed ON e.EvaluationId = ed.EvaluationId
                    INNER JOIN AnswerSheets a ON e.AnswerSheetId = a.AnswerSheetId
                    INNER JOIN Students st ON a.StudentId = st.StudentId
                    INNER JOIN Subjects s ON a.SubjectId = s.SubjectId
                    WHERE st.RollNumber = @RollNumber", connection); 

                command.Parameters.AddWithValue("@RollNumber", rollNumber);

                using var reader = await command.ExecuteReaderAsync(); 
                if (!reader.HasRows)
                {
                    return 0;
                }

                var evaluation = new Dictionary<string, object> // IDE0090: 'new' expression can be simplified
                {
                    { "rollNumber", rollNumber },
                    { "evaluationData", new List<Dictionary<string, object>>() }, // IDE0090: 'new' expression can be simplified
                    { "blankPages", new List<int>() } // IDE0090: 'new' expression can be simplified
                };

                while (await reader.ReadAsync())
                {
                    if (evaluation["evaluationData"] is List<Dictionary<string, object>> evalData)
                    {
                        evalData.Add(new Dictionary<string, object> // IDE0090: 'new' expression can be simplified
                        {
                            { "questionNumber", reader.GetInt32(2) },
                            { "marks", reader.GetInt32(3) },
                            { "coordinates", new
                            {
                                x = reader.IsDBNull(4) ? (int?)null : reader.GetInt32(4),
                                y = reader.IsDBNull(5) ? (int?)null : reader.GetInt32(5)
                            } },
                            { "pageNumber", reader.IsDBNull(6) ? (int?)null : reader.GetInt32(6) },
                            { "timestamp", reader.GetDateTime(7).ToString("o") }
                        });
                    }

                    if (reader["BlankPages"] != DBNull.Value && evaluation["blankPages"] is List<int> blankPages)
                    {
                        var blankPagesJson = reader.GetString(1);
                        blankPages.AddRange(JsonSerializer.Deserialize<List<int>>(blankPagesJson) ?? new List<int>()); // IDE0090: 'new' expression can be simplified
                    }
                }

                return evaluation;
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to fetch evaluation for roll number {rollNumber}: {ex.Message}", ex);
            }
        }

        // GET: api/AnswerSheet/EvaluationData
        //public async Task<object> GetEvaluationData(string uniqueId)
        //{
        //    // Initialize components of the final response
        //    object mainData = null;
        //    var blankPagesList = new List<int>();
        //    var existingMarksList = new List<object>(); 

        //    try
        //    {
        //        using (var connection = new SqlConnection(ConnectionString))
        //        {
        //            await connection.OpenAsync();

        //            using (var command = new SqlCommand("sp_GetEvaluationData", connection)) 
        //            {
        //                command.CommandType = System.Data.CommandType.StoredProcedure;
        //                command.Parameters.AddWithValue("@UniqueId", uniqueId);

        //                using (var reader = await command.ExecuteReaderAsync())
        //                {
        //                    if (await reader.ReadAsync())
        //                    {
        //                        mainData = new
        //                        {
        //                            subject = reader["Subject"].ToString(),
        //                            uniqueId = reader["UniqueId"].ToString(), 
        //                            answerSheetUrl = reader["AnswerSheetUrl"].ToString(),
        //                            totalQuestions = reader.GetInt32(reader.GetOrdinal("TotalQuestions"))
        //                        };
        //                    }
        //                    else
        //                    {
        //                         return null;
        //                    }

        //                    if (await reader.NextResultAsync()) 
        //                    {
        //                        while (await reader.ReadAsync())
        //                        {
        //                            blankPagesList.Add(reader.GetInt32(reader.GetOrdinal("PageNumber")));
        //                        }
        //                    }

        //                    if (await reader.NextResultAsync())
        //                    {
        //                        while (await reader.ReadAsync())
        //                        {
        //                            existingMarksList.Add(new
        //                            {
        //                                questionNumber = reader.GetInt32(reader.GetOrdinal("QuestionNumber")),
        //                                marks = reader.GetInt32(reader.GetOrdinal("Marks")),
        //                                coordinates = new 
        //                                {
        //                                    x = reader.GetDecimal(reader.GetOrdinal("CoordX")),
        //                                    y = reader.GetDecimal(reader.GetOrdinal("CoordY")),
        //                                    pageNumber = reader.GetInt32(reader.GetOrdinal("CoordPageNumber"))
        //                                },
        //                                timestamp = reader["Timestamp"] != DBNull.Value ? reader["Timestamp"].ToString() : null,
        //                                answerSheetId = reader["AnswerSheetRecordId"] != DBNull.Value ? reader["AnswerSheetRecordId"].ToString() : null
        //                            });
        //                        }
        //                    }
        //                }
        //            }
        //        }

        //        return new
        //        {
        //            subject = ((dynamic)mainData).subject, 
        //            uniqueId = ((dynamic)mainData).uniqueId,
        //            answerSheetUrl = ((dynamic)mainData).answerSheetUrl,
        //            totalQuestions = ((dynamic)mainData).totalQuestions,
        //            blankPages = blankPagesList,
        //            existingMarks = existingMarksList
        //        };
        //    }
        //    catch (SqlException ex)
        //    {
        //        Console.WriteLine($"SQL Error in GetEvaluationData for uniqueId {uniqueId}: {ex.Message}");
        //        throw new Exception($"Database error while fetching evaluation data: {ex.Message}", ex);
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine($"Error in GetEvaluationData for uniqueId {uniqueId}: {ex.Message}");
        //        throw new Exception($"Failed to fetch evaluation data: {ex.Message}", ex);
        //    }
        //}       

        public async Task<DataSet> GetEvaluationData(string uniqueId)
        {
            DataSet ds = new DataSet();
            using var con = new SqlConnection(ConnectionString);
            using var cmd = new SqlCommand("sp_GetEvaluationData", con)
            {
                CommandType = CommandType.StoredProcedure
            };

            cmd.Parameters.AddWithValue("@UniqueId", uniqueId);
            using var adp = new SqlDataAdapter(cmd);
                try
            {
                adp.Fill(ds);
            }
            catch
            {
                ds = null;
            }
            return ds;
        }


        // POST: api/AnswerSheet/SubmitEvaluation
        public async Task<string> SubmitEvaluation(string? subject, string? rollNumber, string? blankPages, string? evaluationData)
        {
            try
            {
                using var connection = new SqlConnection(ConnectionString); // IDE0063: already simplified
                await connection.OpenAsync();

                using var command = new SqlCommand("sp_SubmitEvaluation", connection)
                {
                    CommandType = CommandType.StoredProcedure
                }; // IDE0063: already simplified

                command.Parameters.AddWithValue("@SubjectCode", subject ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@RollNumber", rollNumber ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@BlankPages", blankPages ?? "[]");
                command.Parameters.AddWithValue("@EvaluationData", evaluationData ?? "[]");
                command.Parameters.AddWithValue("@CreatedBy", "system");
                var evaluationGuidParam = new SqlParameter("@EvaluationGuid", SqlDbType.VarChar, 50)
                {
                    Direction = ParameterDirection.Output
                };
                command.Parameters.Add(evaluationGuidParam);

                await command.ExecuteNonQueryAsync();
                return evaluationGuidParam.Value?.ToString() ?? throw new Exception("EvaluationGuid not returned");
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to submit evaluation: " + ex.Message, ex);
            }
        }

        public async Task MasterUserLog(int UniqueId, string status, string Filename, string ip)
        {
            using var con = new SqlConnection(ConnectionString);
            using var cmd = new SqlCommand("Insert_MasterUser_Log", con)
            {
                CommandType = CommandType.StoredProcedure
            };

            cmd.Parameters.AddWithValue("@UniqueID", UniqueId);
            cmd.Parameters.AddWithValue("@status", status);
            cmd.Parameters.AddWithValue("@filename", Filename);
            cmd.Parameters.AddWithValue("@ip", ip); 

            try
            {
                await con.OpenAsync();
                await cmd.ExecuteNonQueryAsync();
            }
            catch (Exception ex)
            {
                throw new Exception("Failed to log master user activity: " + ex.Message, ex);
            }
            finally
            {
                await con.CloseAsync();
            }
        }


    }
}